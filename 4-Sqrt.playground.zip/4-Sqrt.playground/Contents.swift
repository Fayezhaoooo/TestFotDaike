//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// 4
//sqrt

class Solution {
    func mySqrt(x: Int) -> Int {
        if x == 0 {return 0}
        
        var i = x
        while(i > x / i) {
            i = (i + x / i) / 2
        }
        return Int(i)
    }
}
