//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//2
// Number First
class Solution {
    func numberFirst(inout nums: [Int]) {
        let nonZeros = nums.filter{ $0 != 0 }.sort()
        let zeros = nums.filter{ $0 == 0 }
        
        nums = nonZeros + zeros
    }
}
